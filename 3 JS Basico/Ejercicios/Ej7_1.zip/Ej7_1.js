// - Un nuevo Set con los nombres de tu familia
const familia = new Set(["Ezequiel", "Nicolas", "Laura", "Leila"]);

// - Modifica el Set original añadiendo tu nombre (duplicado) (debería darte lo mismo)
familia.add("Ezequiel");

// - Modifica el Set original añadiendo el nombre "Javascript" (ya que empieza a formar parte de tu vida ;)
familia.add("Javascript");